#!/bin/bash
apt update
apt install -y python3-venv python3-pip

sleep  10
#if [[ `pip` =~ "${+,*} not found" ]] then
pip install pika
#fi
